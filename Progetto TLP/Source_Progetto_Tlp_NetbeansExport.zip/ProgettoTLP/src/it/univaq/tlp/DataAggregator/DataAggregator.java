/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.DataAggregator;

import it.univaq.tlp.model.Datalayer;
import it.univaq.tlp.model.DatalayerFactory;
import it.univaq.tlp.model.Post;
import it.univaq.tlp.model.Sorgente;
import it.univaq.tlp.social.Connector;
import it.univaq.tlp.social.facebook.FacebookConnector;
import it.univaq.tlp.social.SocialPost;
import it.univaq.tlp.social.twitter.TwitterConnector;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections4.ListUtils;

/**
 * Classe che aggrega i dati tra database e connettori;
 * Avvia la ricerca tramite connettori e salva i risultti nel database tramite datalayer.
 */
public class DataAggregator {

    private Map<String, Connector> connectorMap = new HashMap<>();
    private Datalayer datalayer;

    /**
     * Costruttore di classe, inizializza il datalayer e la mappa che identifica i connettori disponibili.
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public DataAggregator() throws ClassNotFoundException, SQLException {

        datalayer = DatalayerFactory.getFactory("mysql").createDatalayer();
        connectorMap.put("facebook", new FacebookConnector());
        connectorMap.put("twitter", new TwitterConnector());
        connectorMap.put("hashtag", new TwitterConnector());
    }

    /**
     * Salva i risultati della ricerca nel database
     * @param beginTime La data minima di creazione di un risultato
     * @param endTime La data massima di creazione di un risultato
     */
    public void saveResult(Date beginTime, Date endTime) {
        List<Post> result;
        result = adaptSocialPostToPost(getPosts(beginTime,endTime));
        for(Post post : result){
            datalayer.addPost(post);
        }
    }
/**
 * Inizializza la ricerca nei connettori e restituisce i dati raccolti sotto forma di SocialPost.
 * @param beginTime La data minima di creazione dei post cercati
 * @param endTime La data massima di creazione dei post cercti
 * @return I post raccolti dai connetteri nel range di Date dato
 */
    private List<SocialPost> getPosts(Date beginTime, Date endTime) {
        List<SocialPost> result = new ArrayList();
        List<Sorgente> sorgenti = datalayer.getAllSorgenti();
        for(Sorgente sorgente : sorgenti){
           System.out.println("Scarico i risultati per la sorgente: "+sorgente.getName());
            List<SocialPost> currentList;
           String type = sorgente.getType();
           if (type.equals("hashtag")){
            currentList = connectorMap.get(sorgente.getType()).getPostsByHashTag(sorgente.getPageName(), beginTime, endTime);
           }else{
            currentList = connectorMap.get(sorgente.getType()).getPostsByPage(sorgente.getPageName(), beginTime, endTime);
           }
            result = ListUtils.union(result, currentList);
        }
        return result;
    }
/**
 * Adatta una lista di SocialPost passata ad una lista di Post.
 * @param posts Lista di SocialPost da convertire
 * @return Lista di Post relativa alla lista passata
 */
    private List<Post> adaptSocialPostToPost(List<SocialPost> posts) {
        List<Post> result = new ArrayList();
        for (SocialPost socialPost : posts){
            Post currentPost = datalayer.createPost();
            currentPost.setDate(socialPost.getCreationDate());
            currentPost.setLink(socialPost.getLink());
            currentPost.setSorgente(datalayer.getSorgenteByPagina(socialPost.getSorgente()));
            currentPost.setText(socialPost.getText());
            //currentPost.setPolarity(TopicExtractor.getPolarity(currentPost));
            result.add(currentPost);
        }
        return result;
    }

}
