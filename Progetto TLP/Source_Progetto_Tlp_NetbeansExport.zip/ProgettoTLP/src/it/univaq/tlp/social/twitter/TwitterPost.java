/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.social.twitter;

import it.univaq.tlp.social.SocialPost;
import java.util.Date;

/**
 * Identifica l'oggetto restituito da un TwitterConnector.
 */
public class TwitterPost implements SocialPost {

    private Date _date;
    private String _link;
    private String _text;
    private String _sorgente;
    /**
     * Costruttore di classe, inizializza gli attributi di stato a valori di default.
     */
    public TwitterPost() {
        _date = null;
        _link = "";
        _text = "";
        _sorgente = "";
    }

    @Override
    public Date getCreationDate() {
        return _date;
    }

    @Override
    public String getLink() {
        return _link;
    }

    @Override
    public String getText() {
        return _text;
    }

    @Override
    public void setCreationDate(Date date) {
        _date = date;
    }

    @Override
    public void setLink(String link) {
        _link = link;
    }

    @Override
    public void setText(String text) {
        _text = text;
    }

    @Override
    public String getSorgente() {
        return _sorgente;
    }

    @Override
    public void setSorgente(String sorgente) {
        _sorgente = sorgente;
    }
}
