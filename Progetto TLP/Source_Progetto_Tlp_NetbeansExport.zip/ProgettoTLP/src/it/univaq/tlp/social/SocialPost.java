/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.social;

import java.util.Date;

/**
 *
 * Classe contenitore che identifica i Post restituiti dalle API dei social network utilizzate.
 */
public interface SocialPost {
    /**
     * 
     * @return L'attributo creation date restituito dalle API
     */
    public Date getCreationDate();
    /**
     * 
     * @return L'attributo link restituito dalle API
     */
    public String getLink();
    /**
     * 
     * @return L'attributo message restituito dalle API
     */
    public String getText();
    /**
     * 
     * @return La pagina sorgente da cui dipende il Post
     */
    public String getSorgente();
    /**
     * 
     * @param sorgente La sorgente da settare
     */
    public void setSorgente(String sorgente);
    /**
     * 
     * @param date La data da settare
     */
    public void setCreationDate(Date date);
    /**
     * 
     * @param link  Il link da settare
     */
    public void setLink(String link);
    /**
     * 
     * @param text Il testo da settare
     */
    public void setText(String text);
    
    
}
