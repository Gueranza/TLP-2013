/*
 *  * Progetto TLP 2013/2014   
 *
 */

package it.univaq.tlp.social.facebook;

/**
 *
 * Factory per la creazione di un Adapter per le API di Facebook.
 */
public abstract class FacebookAdapterFactory {
    /**
     * 
     * @return Il factory per la creazione dell'adapter per le API di Facebook usate correntemente
     */
     static FacebookAdapterFactory getFactory(){
        return new Facebook4jAdapterFactory();
    }
    /**
     * 
     * @return L'adapter per le API di facebook usate correntemente
     */
     public abstract FacebookAdapter createAdapter();
}
