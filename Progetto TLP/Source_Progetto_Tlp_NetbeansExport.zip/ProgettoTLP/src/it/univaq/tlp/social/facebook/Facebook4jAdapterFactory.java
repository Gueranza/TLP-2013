/*
 *  * Progetto TLP 2013/2014   
 *
 */

package it.univaq.tlp.social.facebook;


public class Facebook4jAdapterFactory extends FacebookAdapterFactory {
    
    Facebook4jAdapterFactory(){
        
    }
    @Override
     public FacebookAdapter createAdapter() {
        return new Facebook4jAdapter();
    }

}
