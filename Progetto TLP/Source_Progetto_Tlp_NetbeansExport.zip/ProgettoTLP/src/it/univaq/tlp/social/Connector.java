/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.social;

import java.util.Date;
import java.util.List;

/**
 * Classe che fornisce funzionalità per il collegamento tra le API dei social network e il DataAggregator.
 */
public interface Connector {
    
   
    /**
     * Metodo che restituisce i SocialPost, presi da una pagina data, creati all'interno dell'intervallo di date passate
     * @param page Pagina su cui cercare i post
     * @param beginTime Data di inizio intervallo
     * @param endTime Data di fine intervallo
     * @return Lista di  SocialPost
     */
    public List<SocialPost> getPostsByPage(String page, Date beginTime, Date endTime);
    /**
     * Metodo che restituisce i SocialPost che hanno l'HashTag dato creti all'interno dell'intervallo di date dato
     * @param hashTag HashTag da ricercare
     * @param beginTime Data di inizio intervallo
     * @param endTime Data di fine intervallo
     * @return Lista di  SocialPost
     */
    public List<SocialPost> getPostsByHashTag(String hashTag, Date beginTime, Date endTime);
    
}
