/*
 *  * Progetto TLP 2013/2014   
 *
 */

package it.univaq.tlp.social.twitter;


public class Twitter4jAdapterFactory extends TwitterAdapterFactory{
    
    Twitter4jAdapterFactory(){
        
    }
    @Override
     public TwitterAdapter createAdapter() {
        return new Twitter4jAdapter();
    }
    
}
