/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.social.twitter;

import it.univaq.tlp.social.SocialPost;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import twitter4j.Paging;
import twitter4j.Query;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;

public class Twitter4jAdapter implements TwitterAdapter {

    private Twitter _twitter;
    private int limit_result_for_page = 50; //max 100

    /**
     * Costruttore di classe, Inizializz l'oggetto Twitter della libreria
     * Twitter4j con le configurazioni della nostra applicazione facebook.
     */
     Twitter4jAdapter() {
        ConfigurationBuilder cb = new ConfigurationBuilder();
        cb.setDebugEnabled(true)
                .setOAuthConsumerKey("t6auWj5TFuKc1NNhg5ZbQ")
                .setOAuthConsumerSecret("P1Ziav2gyD3lXavk8sv3YJf507hYvdwmNJEHEb0X5Oc")
                .setOAuthAccessToken("312222102-j10URUgvdg9RtJ8SgfuW1b2SwdYTj6YNeeIfrv4E")
                .setOAuthAccessTokenSecret("qfOLMKe1ita9oM3RvfW82NynbXej47vgHm6ieHuFc");
        TwitterFactory tf = new TwitterFactory(cb.build());
        _twitter = tf.getInstance();
    }

    @Override
    public List<SocialPost> getPostsByPage(String page, Date beginTime, Date endTime) {
        List<SocialPost> result = new ArrayList();
        try {
            int i = 1;
            Boolean control = true;
            while (control) {
                Paging paging = new Paging(i);
                for (Status twitterStatus : _twitter.getUserTimeline(page, paging)) {
                    if (isInTime(twitterStatus, beginTime)) {
                        SocialPost currentPost = new TwitterPost();
                        currentPost.setCreationDate(twitterStatus.getCreatedAt());

                        currentPost.setText(twitterStatus.getText());
                        currentPost.setSorgente(page);

                        result.add(currentPost);
                    } else {
                        control = false;
                        continue;
                    }
                }
                i++;
            }
        } catch (TwitterException ex) {
            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
        }
        return result;
    }

    @Override
    public List<SocialPost> getPostsByHashTag(String hashTag, Date beginTime, Date endTime) {
        List<SocialPost> result = new ArrayList();
        try {
            Query query = new Query(hashTag);
            query.setCount(limit_result_for_page);
            query.setSince(new SimpleDateFormat("yyyy-MM-dd").format(beginTime));
            long last_id = 0;
            long old_max_id = query.getMaxId();
            while (last_id != old_max_id) {
                old_max_id = query.getMaxId();
                for (Status twitterStatus : _twitter.search(query).getTweets()) {

                    SocialPost currentPost = new TwitterPost();
                    currentPost.setCreationDate(twitterStatus.getCreatedAt());
                    currentPost.setText(twitterStatus.getText());
                    currentPost.setSorgente(hashTag);
                    result.add(currentPost);
                    last_id = twitterStatus.getId();

                }
                query.setMaxId(last_id);
            }
        } catch (TwitterException ex) {

            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
            return result;
        }
        return result;
    }

    /**
     * Controlla se il post dato è stato creato dopo il beginTime
     *
     * @param twitterStatus Post da controllare
     * @param beginTime Data di partenza della ricerca
     * @return true se il post è stato creato dopo il beginTime, false
     * altrimenti
     */
    private boolean isInTime(Status twitterStatus, Date beginTime) {
        Date creationDate = twitterStatus.getCreatedAt();

        return creationDate.after(beginTime);
    }
}
