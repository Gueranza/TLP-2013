/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.social.facebook;

import it.univaq.tlp.social.SocialPost;
import java.util.Date;
import java.util.List;

/**
 *
 * Adapter per le API di facebook.
 */
public interface FacebookAdapter {
    /**
     * Inizializza la ricerca dei post su una pagina, e nel range di date, dati
     * @param page La pagina facebook su cui ricercare
     * @param beginTime Limite minimo del range di date
     * @param endTime Limite massimo del range di date
     * @return Lista di social post contenuti nella pagina data e creati all'interno del range di date dato
     */
    public List<SocialPost> getPostsByPage(String page, Date beginTime, Date endTime);
    /**
     * Inizializza la ricerca dei post con un hashtg, e nel range di date, dati
     * @param hashTag L'hashtag da ricercare
     * @param beginTime Limite minimo del range di date
     * @param endTime Limite massimo del range di date
     * @return Lista di social post contenente il dato tag e create all'interno del range di date dato
     */
    public List<SocialPost> getPostsByHashTag(String hashTag, Date beginTime, Date endTime);
    
}
