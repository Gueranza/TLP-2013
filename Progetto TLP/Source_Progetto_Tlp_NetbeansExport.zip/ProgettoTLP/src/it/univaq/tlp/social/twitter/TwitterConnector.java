/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.social.twitter;

import it.univaq.tlp.social.Connector;
import it.univaq.tlp.social.SocialPost;
import java.util.Date;
import java.util.List;

/**
 * Fornisce le funzionalità per il collegamento con le API di Twitter.
 */
public class TwitterConnector implements Connector {

    private TwitterAdapter _adapter;
    /**
     * Costruttore di classe, inizializza il TwitterAdapter tramite un factory.
     */
    public TwitterConnector() {
        _adapter = TwitterAdapterFactory.getFactory().createAdapter();
    }

    @Override
    public List<SocialPost> getPostsByPage(String page, Date beginTime, Date endTime) {

        return _adapter.getPostsByPage(page, beginTime, endTime);
    }

    @Override
    public List<SocialPost> getPostsByHashTag(String hashTag, Date beginTime, Date endTime) {


        return _adapter.getPostsByHashTag(hashTag, beginTime, endTime);
    }
}
