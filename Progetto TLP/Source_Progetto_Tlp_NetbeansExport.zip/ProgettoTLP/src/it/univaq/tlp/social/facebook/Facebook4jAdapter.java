/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.social.facebook;

import facebook4j.Facebook;
import facebook4j.FacebookException;
import facebook4j.FacebookFactory;
import facebook4j.Paging;
import facebook4j.Post;
import facebook4j.Reading;
import facebook4j.ResponseList;
import facebook4j.conf.ConfigurationBuilder;
import it.univaq.tlp.social.SocialPost;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


class Facebook4jAdapter implements FacebookAdapter {

    private Facebook _facebook;

    /**
     * Costruttore di classe, Inizializz l'oggetto Facebook della libreria
     * Facebook4j con le configurazioni della nostra applicazione facebook.
     */
     Facebook4jAdapter() {
        ConfigurationBuilder cb = new ConfigurationBuilder();
        cb.setDebugEnabled(false)
                .setOAuthAppId("158171681031023")
                .setOAuthAppSecret("4f1e1ca8d3fd0218092ee1d3d9eea384")
                .setOAuthAccessToken("CAACP2zbcg28BAM5lfE361HsOik74PYdV8JkchtKhyV9ZCOZBSL7ZApoRbcULmOPD5bt5XHMbwKaMVATLZBXbaCTK2jXdmbI5qHCWJPh6hpr0oH0tRWjU6JEan0VfXJrtqBnIoFboiwdOE32ZCg8Ct7oHnHRSF3WnvrtuYlMIa8AoCarn97APDJhwK3qPlgm8ZD")
                .setOAuthPermissions("id,created_time,message,icon,link");
        FacebookFactory ff = new FacebookFactory(cb.build());
        _facebook = ff.getInstance();
    }

    @Override
    public List<SocialPost> getPostsByPage(String page, Date beginTime, Date endTime) {
        List<SocialPost> result = new ArrayList();
        Reading reading = new Reading();
        reading.since(beginTime);
        try {
            ResponseList<Post> posts = _facebook.getFeed(page, reading);
            Boolean control = true;
            while (posts.size() > 0 && control) {
                for (Post facebookPost : posts) {
                    if (!(facebookPost.getMessage() != null && facebookPost.getIcon() != null)) {
                        continue;
                    }
                    if (!isInTime(facebookPost, beginTime)) {
                        control = false;
                        continue;
                    }
                    SocialPost currentPost = new FacebookPost();
                    currentPost.setCreationDate(facebookPost.getCreatedTime());
                    currentPost.setText(facebookPost.getMessage());
                    currentPost.setSorgente(page);
                    if (facebookPost.getLink() != null) {
                        currentPost.setLink(facebookPost.getLink().toString());
                    }
                    result.add(currentPost);

                }

                Paging<Post> pag = posts.getPaging();
                posts = _facebook.fetchNext(pag);

            }
        } catch (FacebookException ex) {
            return result;
        }
        return result;
    }

    @Override
    public List<SocialPost> getPostsByHashTag(String hashTag, Date beginTime, Date endTime) {
        List<SocialPost> result = new ArrayList();
        try {
            for (Post facebookPost : _facebook.searchPosts(hashTag)) {
                if (!isInTime(facebookPost, beginTime)) {
                    continue;
                }
                SocialPost currentPost = new FacebookPost();
                currentPost.setCreationDate(facebookPost.getCreatedTime());
                currentPost.setLink(facebookPost.getLink().toString());
                currentPost.setText(facebookPost.getMessage());
                currentPost.setSorgente(hashTag);
                result.add(currentPost);
            }
        } catch (FacebookException ex) {
            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
        }
        return result;
    }

    /**
     * Controlla se il post dato è stato creato dopo il beginTime
     *
     * @param facebookPost Post da controllare
     * @param beginTime Data di partenza della ricerca
     * @return true se il post è stato creato dopo il beginTime, false
     * altrimenti
     */
    private boolean isInTime(Post facebookPost, Date beginTime) {
        Date creationDate = facebookPost.getCreatedTime();
        return creationDate.after(beginTime);
    }
}
