/*
 *  * Progetto TLP 2013/2014   
 *
 */

package it.univaq.tlp.social.twitter;

/**
 *
 * Factory per la creazione di un Adapter per le API di Twitter.
 */
public abstract class TwitterAdapterFactory {
    /**
     * 
     * @return Il factory per la creazione dell'adapter per le API di Twitter usate correntemente
     */
     static TwitterAdapterFactory getFactory(){
        return new Twitter4jAdapterFactory();
    }
    /**
     * 
     * @return L'adapter per le API di Twitter usate correntemente
     */
     public abstract TwitterAdapter createAdapter();
}
