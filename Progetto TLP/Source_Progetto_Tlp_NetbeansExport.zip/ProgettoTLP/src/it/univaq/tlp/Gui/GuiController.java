package it.univaq.tlp.Gui;

import javax.swing.*;
import java.util.Date;
import java.util.Timer;

/**
 *
 * Controller per la gui, offre le funzionalità per far partire e/o stoppare il
 * DataAggregator.
 */
public class GuiController {

    private Timer _timer;
    private PostFetcher _task;

    /**
     * Funzione che avvia il DataAggregator sotto forma di thread da eseguire ogni intervalMillisecs di tempo.
     * @param beginDate Data minima per la ricerca di posts
     * @param updatedAt Label da aggiornare con l'ultima data di ricerca svolta
     */
    public void runDataAggregator(Date beginDate, JLabel updatedAt) {
        Long intervalMillisecs = 2*60*1000L;//1440 * 60 * 1000L; //24h
        _timer = new Timer("Data Aggregator");

        _task = new PostFetcher(beginDate, updatedAt);
        _timer.schedule(_task, 0, intervalMillisecs);
    }

    /**
     * Stoppa il data aggregator.
     */
    public void Stop() {
        _task.cancel();
        _task.stopSearch();
        _timer.cancel();
        System.out.println("L'applicazione verrà stoppata non appena finirà l'ultima ricerca attiva...");
    }
}

