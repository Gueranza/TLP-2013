package it.univaq.tlp.Gui;


import it.univaq.tlp.DataAggregator.DataAggregator;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.TimerTask;
import javax.swing.JLabel;

/**
 *
 * Classe che identifica il task da svolgere ogni intervallo di tempo.
 */
class PostFetcher extends TimerTask {

    private Date _beginDate;
    private JLabel _updatedAt;
    private Boolean stopped = false;

    /**
     * Costruttore di classe
     *
     * @param beginDate Data minima d ricerca per i post
     * @param updatedAt Label da aggiornare con l'ultima ricerca effettuata
     */
    PostFetcher(Date beginDate, JLabel updatedAt) {
        _beginDate = beginDate;
        _updatedAt = updatedAt;
    }


    @Override
    public void run() {
        try {
            Calendar now = Calendar.getInstance(TimeZone.getTimeZone("Europe/Rome"));

            System.out.println("Raccolgo informazioni da " + _beginDate + " "
                    + " a " + now.getTime());
            _updatedAt.setText("Ultimo aggiornamento"+now.getTime().toLocaleString());
            DataAggregator dataAggregator = new DataAggregator();

            dataAggregator.saveResult(_beginDate, now.getTime());
            PrintMessages();
        } catch (ClassNotFoundException ex) {
            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
        } catch (SQLException ex) {
            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
        }
    }
 

    /**
     * Stampa il messaggio di fine ricerca.
     *
     */
    private void PrintMessages() {
        Calendar finishedTime = Calendar.getInstance(TimeZone.getTimeZone("Europe/Rome"));
        System.out.println("Finito il " + finishedTime.getTime());
        if (!stopped) {
            System.out.println("Attendo 24h per ricominciare");
            _beginDate = Calendar.getInstance(TimeZone.getTimeZone("Europe/Rome")).getTime();
        } else {
            System.out.println("DataAggregator stoppato...");
        }
    }

    /**
     * Stoppa il data aggregator.s
     */
    public void stopSearch() {
        stopped = true;
    }
}
