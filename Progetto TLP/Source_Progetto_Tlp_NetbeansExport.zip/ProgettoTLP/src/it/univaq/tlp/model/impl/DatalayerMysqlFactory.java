/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package it.univaq.tlp.model.impl;

import it.univaq.tlp.db.Config;
import it.univaq.tlp.model.DatalayerFactory;
import it.univaq.tlp.model.Datalayer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Stefano
 */
public class DatalayerMysqlFactory extends DatalayerFactory {

    @Override
    public Datalayer createDatalayer() {
        try {
            Connection connection;
            Datalayer datalayer;
            Class.forName("com.mysql.jdbc.Driver");

            connection = DriverManager.getConnection("jdbc:mysql://" + Config.hostname + ":" + Config.port + "/" + Config.db_name, Config.username, Config.password);

            datalayer = new DatalayerMysqlImpl(connection);

            return datalayer;
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
        }
        return null;
    }
}
