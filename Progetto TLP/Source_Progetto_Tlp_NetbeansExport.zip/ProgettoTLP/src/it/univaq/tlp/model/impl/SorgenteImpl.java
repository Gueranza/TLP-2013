/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.model.impl;

import it.univaq.tlp.model.Datalayer;
import it.univaq.tlp.model.Sorgente;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SorgenteImpl implements Sorgente {

    private int _id;
    private String _name;
    private String _pageName;
    private String _link;
    private String _type;
    private int _authorId;
    private String _icon;
    private Datalayer _datalayer;
    /**
     * Costruttore di classe, inizializza il datalayer e setta gli attributi dai risultati di un query
     * @param datalayer
     * @param data
     * @throws SQLException 
     */
    SorgenteImpl(Datalayer datalayer, ResultSet data )throws SQLException{
        _id = data.getInt("ID");
        _name = data.getString("Nome");
        _pageName = data.getString("Pagina");
        _link = data.getString("Link");
        _type = data.getString("Tipo");
        _authorId = data.getInt("Autore");
        _icon = data.getString("Icona");
        _datalayer = datalayer;
    }
    @Override
    public int getId() {
        return _id;
    }

    @Override
    public String getName() {
        return _name;
    }

    @Override
    public String getPageName() {
        return _pageName;
    }

    @Override
    public String getLink() {
        return _link;
    }

    @Override
    public String getType() {
        return _type;
    }

    @Override
    public int getAuthorId() {
        return _authorId;
    }

    @Override
    public String getIcon() {
        return _icon;
    }
}
