/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.model;

/**
 * Classe contenitore che identifica la tabella "Sorgente" del database.
 */
public interface Sorgente {
    /**
     *
     * @return l'id univoco della sorgente
     */
    public int getId();
    /**
     *
     * @return il nome della sorgente
     */
    public String getName();
    /**
     *
     * @return il nome della pagina
     */
    public String getPageName();
    /**
     *
     * @return il link alla pagina
     */
    public String getLink();
    /**
     *
     * @return il tipo di sorgente (facebook,twitter,hashtag)
     */
    public String getType();
    /**
     *
     * @return l'id dell'utente che ha creato la sorgente
     */
    public int getAuthorId();
    /**
     *
     * @return l'icona della sorgente
     */
    public String getIcon();
}
