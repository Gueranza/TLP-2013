/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package it.univaq.tlp.model;


import it.univaq.tlp.model.impl.DatalayerMysqlFactory;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * Factory per la creazione del datalayer per il tipo di database usato.
 */
public abstract class DatalayerFactory {
    /**
     * Restituisce il FactoryDatalayer collegato nella datalayerMap al type passato
     * @param type Il tipo di database utilizzato
     * @return L'implementazione corretta del datalayer
     */
    public static DatalayerFactory getFactory(String type){
        Map<String,DatalayerFactory> datalayerMap = new HashMap();
        datalayerMap.put("mysql", new DatalayerMysqlFactory());
        
        return datalayerMap.get(type);
    }
    /**
     * 
     * @return Il datlayer corrispondente
     */
    public abstract Datalayer createDatalayer();

}
