/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.model.impl;

import it.univaq.tlp.model.Datalayer;
import it.univaq.tlp.model.Post;
import it.univaq.tlp.model.Sorgente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatalayerMysqlImpl implements Datalayer {

    private PreparedStatement aPost, gPostById, gSorgenteById, gSorgenteByPagina, gAllSorgenti;

    DatalayerMysqlImpl(Connection connection) throws SQLException {
        aPost = connection.prepareStatement("INSERT IGNORE INTO Post(Link, Data, ID_Fonte,Text) VALUES(?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
        gPostById = connection.prepareStatement("SELECT * FROM Post WHERE ID=?");
        gSorgenteById = connection.prepareStatement("SELECT * FROM Sorgenti WHERE ID=?");
        gSorgenteByPagina = connection.prepareStatement("SELECT * FROM Sorgenti WHERE Pagina=?");
        gAllSorgenti = connection.prepareStatement("SELECT * FROM Sorgenti");
    }

    @Override
    public Post createPost() {
        return new PostImpl(this);
    }

    @Override
    public Post addPost(Post post) {
        try {
            ResultSet key = null;
            aPost.setString(1, post.getLink());
            aPost.setTimestamp(2, new java.sql.Timestamp(post.getDate().getTime()));
            //aPost.setString(3, post.getPolarity());
            aPost.setInt(3, post.getSorgente().getId());
            aPost.setString(4, post.getText());
            if (aPost.executeUpdate() == 1) {
                key = aPost.getGeneratedKeys();
                if (key.next()) {
                    return getPostById(key.getInt(1));
                }
            }
        } catch (SQLException ex) {
            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
        }
        return null;

    }

    @Override
    public Sorgente getSorgenteById(int id) {
        try {
            ResultSet rs;
            gSorgenteById.setInt(1, id);
            rs = gSorgenteById.executeQuery();
            if (rs.next()) {
                return new SorgenteImpl(this, rs);
            }
        } catch (SQLException ex) {
            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
        }
        return null;
    }
    public Sorgente getSorgenteByPagina(String paginaSorgente) {
        try {
            ResultSet rs;
            gSorgenteByPagina.setString(1, paginaSorgente);
            rs = gSorgenteByPagina.executeQuery();
            if (rs.next()) {
                return new SorgenteImpl(this, rs);
            }
        } catch (SQLException ex) {
            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
        }
        return null;
    }

    @Override
    public List<Sorgente> getAllSorgenti() {
        try {
            ResultSet rs;
            List<Sorgente> result = new ArrayList<>();
            rs = gAllSorgenti.executeQuery();
            while (rs.next()) {
                result.add(new SorgenteImpl(this, rs));
            }
            return result;
        } catch (SQLException ex) {
            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
        }
        return null;
    }

    @Override
    public Post getPostById(int id) {
        try {
            ResultSet rs;
            gPostById.setInt(1, id);
            rs = gPostById.executeQuery();
            if (rs.next()) {
                return new PostImpl(this, rs);
            }
        } catch (SQLException ex) {
            System.out.println("***ERRORE***");
            System.out.println(ex.getMessage());
            System.out.println("************");
        }
        return null;
    }
}
