/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.model;

import java.util.List;

/**
 * Classe utilizzata per accedere, controllare, salvare i dati del database<br/>
 *
 * @author Stefano
 */
public interface Datalayer {

    /**
     * Crea un nuovo post vuoto
     *
     * @return Il post creato
     */
    public Post createPost();

    /**
     * Salva il post, passato come argomento, sul database
     *
     * @param post Il post da aggiungere
     * @return Il post aggiunto
     */
    public Post addPost(Post post);

    /**
     * Restituisce la sorgente identificata dall'id passato come parametro
     *
     * @param sorgenteId L'id della sorgente da caricare
     * @return La sorgente corrispondente all'id
     */
    public Sorgente getSorgenteById(int id);

    /**
     * Restituisce la sorgente indetificata dalla Nome pagina passato come
     * parametro
     *
     * @param paginaSorgente Nome pagina da ricercre
     * @return La sorgente con il nome pagina dato
     */
    public Sorgente getSorgenteByPagina(String paginaSorgente);

    /**
     *
     * @return La lista contenenti tutte le sorgenti nel database
     */
    public List<Sorgente> getAllSorgenti();
    /**
     * Restituisce il post identificato dall'id passato come parametro
     * @param id L'id del post da caricare
     * @return Il post corrispondente all'id
     */
    public Post getPostById(int id);
}
