/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.model;

import java.util.Date;

/**
 * Classe contenitore che identifica la tabella "Post" del database
 * @author Stefano
 */
public interface Post {
    /**
     *
     * @return l'id univoco del post
     */
    public int getId();
    /**
     *
     * @return il link del post
     */
    public String getLink();
    /**
     * 
     * @param link Il link da settare
     */
    public void setLink(String link);
    /**
     *
     * @return la data di creazione del post
     */
    public Date getDate();
    /**
     *
     * @param date La data da settare
     */
    public void setDate(Date date);
    /**
     *
     * @return la polarità del post
     */
    public String getPolarity();
    /**
     *
     * @param polarity La polarità da settare
     */
    public void setPolarity(String polarity);
    /**
     *
     * @return La sorgente del post
     */
    public Sorgente getSorgente();
    /**
     *
     * @param sorgente La sorgente da settare
     */
    public void setSorgente(Sorgente sorgente);
    /**
     *
     * @return il testo del post
     */
    public String getText();
    /**
     *
     * @param text Il testo da settare
     */
    public void setText(String text);
}
