/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.model.impl;

import it.univaq.tlp.model.Datalayer;
import it.univaq.tlp.model.Post;
import it.univaq.tlp.model.Sorgente;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

 public class PostImpl implements Post {

    private int _id;
    private String _link;
    private Date _date;
    private String _polarity;
    private Sorgente _sorgente;
    private int _sorgenteId;
    private String _text;
    private Datalayer _datalayer;
/**
 * Costruttore di classe, inizializza il datalayer e setta gli attributi a valori di default
 * @param datalayer Datalayer che ha creato l'oggetto
 */
     PostImpl(Datalayer datalayer) {
        _id = 0;
        _link = "";
        _date = null;
        _polarity = "0";
        _sorgente = null;
        _sorgenteId = 0;
        _text = "";
        _datalayer = datalayer;
    }
     /**
      * Costruttore di classe, inizializza il datalayer e setta gli attributi dai risultati di una query 
      * @param datalayer Datlayer che ha creato l'oggetto
      * @param data ResultSet di una query
      * @throws SQLException 
      */
     PostImpl(Datalayer datalayer, ResultSet data) throws SQLException {
        _id = data.getInt("ID");
        _link = data.getString("Link");
        _date = data.getDate("Data");
        _polarity = data.getString("Polarity");
        _sorgente = null;
        _sorgenteId = data.getInt("ID_Fonte");
        _text = data.getString("Text");
        _datalayer = datalayer;
    }

    @Override
     public int getId() {
        return _id;
    }

    @Override
     public String getLink() {
        return _link;
    }

    @Override
     public void setLink(String link) {
        _link = link;
    }

    @Override
     public Date getDate() {
        return _date;
    }

    @Override
     public void setDate(Date date) {
        _date = date;
    }

    @Override
     public String getPolarity() {
        return _polarity;
    }

    @Override
     public void setPolarity(String polarity) {
        _polarity = polarity;
    }

    @Override
     public Sorgente getSorgente() {
        if (_sorgente == null) {
            _sorgente = _datalayer.getSorgenteById(_sorgenteId);
        }
        return _sorgente;
    }

    @Override
     public void setSorgente(Sorgente sorgente) {
        _sorgente = sorgente;
    }

    @Override
     public String getText() {
        return _text;
    }

    @Override
     public void setText(String text) {
        _text = text;
    }
}
