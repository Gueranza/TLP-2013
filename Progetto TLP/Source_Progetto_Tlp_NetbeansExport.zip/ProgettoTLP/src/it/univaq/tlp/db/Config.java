/*
 *  * Progetto TLP 2013/2014   
 *
 */
package it.univaq.tlp.db;

/**
 * Classe contenitore delle configurazioni del database.
 */
public class Config {

    public static final String hostname = "localhost";
    public static final String port = "3306";
    public static final String db_name = "tlp";
    public static final String username = "root";
    public static final String password = "";
    
    private Config(){
        
    };
}
